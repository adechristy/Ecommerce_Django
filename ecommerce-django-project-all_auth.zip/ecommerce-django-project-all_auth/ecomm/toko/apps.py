from django.apps import AppConfig


class TokoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'toko'
