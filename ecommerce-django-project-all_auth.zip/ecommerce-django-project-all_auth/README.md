# ecommerce-django-project
Belajar membuat ecommerce website dengan menggunaakan django dan python
